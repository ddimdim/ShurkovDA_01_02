﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShurkovDA_01_02
{
    public class RoadWorks
    {
        public double Width { get; set; }
        public double Length { get; set; }
        public double Weight { get; set; }
        public RoadWorks(double width, double length, double weight)
        {
            Width = width;
            Length = length;
            Weight = weight;
        }
        public virtual double Quality()
        {
            return Math.Round(Width * Length * Weight / 1000, 2);
        }
        public virtual void PrintInfo()
        {
            Console.WriteLine($"Ширина дороги: {Width} м");
            Console.WriteLine($"Длина дороги: {Length} м");
            Console.WriteLine($"Масса дорожного покрытия на 1 кв.м: {Weight} кг");
            Console.WriteLine($"Качество работ: {Quality()}");
        }

    }
}
