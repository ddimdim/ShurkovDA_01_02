﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShurkovDA_01_02
{
    public class RoadWorksWithMonth : RoadWorks
    {
        public int Month { get; set; }
        public RoadWorksWithMonth(double width, double length, double weight, int month) : base(width, length, weight)
        {
            Month = month;
        }
        public override double Quality()
        {
            if (Month >= 5 && Month <= 8)
                return Math.Round(base.Quality() * 1.1, 2);
            else if (Month == 3 || Month == 4 || Month == 9 || Month == 10)
                return Math.Round(base.Quality() * 1.6, 2);
            else
                return Math.Round(base.Quality() * 2.1 + Month * 10, 2);

        }
        public override void PrintInfo()
        {
            base.PrintInfo();
            Console.WriteLine($"Номер месяца: {Month}");
        }
    }
}
