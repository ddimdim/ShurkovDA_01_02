﻿
using ShurkovDA_01_02;

try
{
    //Ввод информации об объектах базового класса
    Console.WriteLine("Введите ширину дороги (м)");
    double width = Double.Parse(Console.ReadLine());
    Console.WriteLine("Введите длину дороги (м)");
    double length = Double.Parse(Console.ReadLine());
    Console.WriteLine("Введите массу дорожного покрытия на 1 кв. м");
    double weight = Double.Parse(Console.ReadLine());
    RoadWorks roadWorks = new RoadWorks(width, length, weight);

    Console.WriteLine("Информация, без учета месяца дорожных работ:");
    Console.WriteLine("-------------------------");
    roadWorks.PrintInfo(); //Вывод информации об объектах базового класса
    Console.WriteLine("-------------------------");

    //Ввод информации об объектах класса потомка
    int month = 0;
    while (month < 1 || month > 12) //Проверка на корректный ввод
    {
        Console.WriteLine("Введите номер месяца дорожных работ");
        month = Int32.Parse(Console.ReadLine());
        if (month < 1 || month > 12)
            Console.WriteLine("Введено некорректное значение номера месяца");
    }
    RoadWorksWithMonth monthWorks = new RoadWorksWithMonth(width, length, weight, month);
    Console.WriteLine("Информация, с учетом месяца дорожных работ:");
    Console.WriteLine("-------------------------");
    monthWorks.PrintInfo(); //Вывод информации, используя класс потомок
    Console.WriteLine("-------------------------");
}
catch
{
    Console.WriteLine("Данные были введены некорректно");
}
Console.ReadKey();






